package org.yaz4j.exception;

public class InitRejectedException extends ZoomException {

  public InitRejectedException() {
    super();
  }

  public InitRejectedException(String message) {
    super(message);
  }
}
