package org.yaz4j.exception;

public class Bib1Exception extends ZoomException {

  private static final long serialVersionUID = 1L;

  public Bib1Exception() {
    super();
  }

  public Bib1Exception(String message) {
    super(message);
  }
}
